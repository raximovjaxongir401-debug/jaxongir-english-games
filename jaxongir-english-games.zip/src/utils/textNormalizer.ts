/**
 * Strict text normalizer according to specifications:
 * 1. Convert to lowercase
 * 2. Unify all apostrophe varieties (' ’ ʻ ʼ `) -> '
 * 3. Remove punctuation: ( ) . , ; : ! ? " “ ”
 * 4. Collapse multiple spaces into one
 * 5. Trim leading and trailing spaces
 */
export function normalizeText(text: string): string {
  if (!text) return '';
  return text
    .toLowerCase()
    .replace(/['’ʻʼ`]/g, "'")
    .replace(/[().,;:!?"“”]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Check if user input matches any of the comma-separated or slash-separated acceptable answers.
 * In addition, handles optional word types in parentheses like (n), (v), (adj)
 */
export function checkAnswerMatch(input: string, acceptedString: string): boolean {
  const normInput = normalizeText(input);
  if (!normInput) return false;

  // Split acceptable answers by comma or slash
  const variants = acceptedString.split(/[,/]/).map(v => v.trim()).filter(Boolean);

  for (const variant of variants) {
    const normVariant = normalizeText(variant);
    if (normInput === normVariant) return true;

    // Handle parentheses: e.g. "claim (v)" -> also match "claim" without parenthetical
    const withoutParens = normalizeText(variant.replace(/\([^)]*\)/g, ''));
    if (withoutParens && normInput === withoutParens) return true;

    // Handle British/American variations: e.g. recognise vs recognize
    const variantUkUs = normVariant.replace(/ise\b/g, 'ize');
    const inputUkUs = normInput.replace(/ise\b/g, 'ize');
    if (inputUkUs === variantUkUs) return true;
  }

  return false;
}

/**
 * Word-by-word diff helper for sentence typing mode
 */
export interface WordDiff {
  word: string;
  isCorrect: boolean;
}

export function compareSentenceWords(userSentence: string, targetSentence: string): {
  userWordsDiff: WordDiff[];
  isFullyCorrect: boolean;
} {
  const cleanTargetWords = targetSentence.split(/\s+/).filter(Boolean);
  const userWords = userSentence.split(/\s+/).filter(Boolean);

  let isFullyCorrect = cleanTargetWords.length === userWords.length;

  const userWordsDiff: WordDiff[] = userWords.map((uw, idx) => {
    const tw = cleanTargetWords[idx];
    if (!tw) {
      isFullyCorrect = false;
      return { word: uw, isCorrect: false };
    }
    const match = normalizeText(uw) === normalizeText(tw);
    if (!match) isFullyCorrect = false;
    return { word: uw, isCorrect: match };
  });

  return { userWordsDiff, isFullyCorrect };
}

/**
 * Generate letter hint: e.g. "He admitted stealing" -> "H_ a_______ s_______"
 */
export function generateLetterHint(sentence: string): string {
  return sentence
    .split(' ')
    .map(word => {
      // preserve punctuation at the end of word if any
      const match = word.match(/^([a-zA-Z0-9'’ʻʼ`]+)([^a-zA-Z0-9'’ʻʼ`]*)$/);
      if (!match) return word;
      const letters = match[1];
      const punct = match[2];
      if (letters.length <= 1) return letters + punct;
      return letters[0] + '_'.repeat(letters.length - 1) + punct;
    })
    .join(' ');
}
