import { FlashcardWord } from '../types';

export const INTRO_SEEN_KEY = 'jaxongir_intro_seen_v1';

export function loadGameData(storageKey: string, fallbackData: FlashcardWord[]): FlashcardWord[] {
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) {
      localStorage.setItem(storageKey, JSON.stringify(fallbackData));
      return fallbackData;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
  } catch (e) {
    console.error('Failed to load from storage key:', storageKey, e);
  }
  return fallbackData;
}

export function saveGameData(storageKey: string, data: FlashcardWord[]): void {
  try {
    localStorage.setItem(storageKey, JSON.stringify(data));
  } catch (e) {
    console.error('Failed to save to storage key:', storageKey, e);
  }
}

export function resetGameData(storageKey: string, initialData: FlashcardWord[]): FlashcardWord[] {
  try {
    localStorage.setItem(storageKey, JSON.stringify(initialData));
  } catch (e) {
    console.error('Failed to reset storage key:', storageKey, e);
  }
  return initialData;
}

export function hasSeenIntro(): boolean {
  try {
    return localStorage.getItem(INTRO_SEEN_KEY) === 'true';
  } catch {
    return false;
  }
}

export function markIntroSeen(): void {
  try {
    localStorage.setItem(INTRO_SEEN_KEY, 'true');
  } catch (e) {
    console.error('Failed to save intro seen flag', e);
  }
}

export function resetIntroFlag(): void {
  try {
    localStorage.removeItem(INTRO_SEEN_KEY);
  } catch (e) {
    console.error('Failed to reset intro seen flag', e);
  }
}
