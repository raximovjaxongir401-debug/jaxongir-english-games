import React from 'react';
import { Play, Sparkles } from 'lucide-react';

interface IntroScreenProps {
  onStart: () => void;
}

export const IntroScreen: React.FC<IntroScreenProps> = ({ onStart }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-paper p-4 overflow-y-auto">
      {/* Background vintage subtle watermark pattern */}
      <div className="relative max-w-md w-full bg-paper2 border-1.5 border-ink rounded-lg p-6 sm:p-8 shadow-retro-lg text-center flex flex-col items-center">
        
        {/* Badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 mb-4 border-1.5 border-ink rounded bg-white font-mono text-xs text-teal-dark font-bold shadow-retro-sm">
          <Sparkles className="w-3.5 h-3.5 text-gold" />
          <span>7 TA FLASHCARD & GRAMMATIKA O'YINI</span>
        </div>

        {/* AT Logo */}
        <div className="relative my-3 flex justify-center">
          <div className="w-[62vw] max-w-[260px] aspect-square rounded-lg border-1.5 border-ink overflow-hidden shadow-retro bg-white">
            <img
              src="/logo.jpg"
              alt="AT with Jaxongir"
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Branding text */}
        <div className="mt-3 mb-6">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-ink font-serif">
            Jaxongir English Games
          </h1>
          <p className="text-clay font-mono text-sm tracking-wider mt-1 font-semibold uppercase">
            with Jaxongir
          </p>
          <div className="w-16 h-0.5 bg-line mx-auto my-3" />
          <p className="text-xs sm:text-sm text-ink/80 leading-relaxed font-serif">
            Multi-level, IELTS va CEFR so'z boyligini mustahkamlash, tezkor testlar va Gerund & Infinitive yozma mashqlari
          </p>
        </div>

        {/* Dominant "Boshlash" button */}
        <button
          onClick={onStart}
          className="w-full py-3.5 px-6 bg-teal hover:bg-teal-dark active:translate-x-0.5 active:translate-y-0.5 text-paper font-serif font-bold text-lg rounded-md border-1.5 border-ink shadow-retro flex items-center justify-center gap-2 cursor-pointer transition-all"
        >
          <Play className="w-5 h-5 fill-current" />
          <span>Boshlash</span>
        </button>

        {/* Footer offline info */}
        <p className="text-[11px] font-mono text-ink/60 mt-4">
          ✓ Oflayn ishlaydi · Qurilmaga o'rnatish mumkin (PWA)
        </p>
      </div>
    </div>
  );
};
