import React from 'react';
import { GameId } from '../types';
import { BookOpen, Sparkles, MapPin, ArrowRightLeft, Layers, Keyboard, Download, Info } from 'lucide-react';

interface GameSummary {
  id: GameId;
  title: string;
  countLabel: string;
  description: string;
  sourceLabel: string;
  icon: React.ReactNode;
  tagColor: string;
}

interface DashboardProps {
  onSelectGame: (gameId: GameId) => void;
  onOpenIntro: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onSelectGame, onOpenIntro }) => {
  const games: GameSummary[] = [
    {
      id: 'navigate-c1',
      title: "Navigate C1 — So'z boyligi",
      countLabel: "865 ta so'z · 12 ta Unit",
      description: "Oxford Navigate C1 Coursebook to'liq so'zlar ro'yxati. O'qituvchi tomonidan tasdiqlangan aniq tarjimalar.",
      sourceLabel: "C1 Advanced",
      icon: <BookOpen className="w-5 h-5 text-teal" />,
      tagColor: "bg-teal/10 text-teal-dark border-teal/30"
    },
    {
      id: 'navigate-b2',
      title: "Navigate B2 — So'z boyligi",
      countLabel: "867 ta so'z · 12 ta Unit",
      description: "Oxford Navigate B2 so'zlar ro'yxati. 6 ta interaktiv rejim va to'liq tahrirlash imkoniyati bilan.",
      sourceLabel: "B2 Upper-Int",
      icon: <BookOpen className="w-5 h-5 text-clay" />,
      tagColor: "bg-clay/10 text-clay border-clay/30"
    },
    {
      id: 'vocab-7-8',
      title: "7+ 8+ Vocabulary",
      countLabel: "440 ta so'z · 22 ta Topic",
      description: "IELTS 7+ va 8+ darajali maxsus mavzulashtirilgan akademik so'zlar to'plami (People, Health, Science va boshqalar).",
      sourceLabel: "IELTS 7.5+",
      icon: <Sparkles className="w-5 h-5 text-gold" />,
      tagColor: "bg-gold/20 text-ink border-gold/40"
    },
    {
      id: 'listening-map',
      title: "Listening Map Vocabulary",
      countLabel: "100 ta so'z · 10 ta Topic",
      description: "IELTS va Multi-level Listening xarita (map) topshiriqlari uchun maxsus yo'nalish va joylashuv lug'ati.",
      sourceLabel: "Listening Map",
      icon: <MapPin className="w-5 h-5 text-teal-dark" />,
      tagColor: "bg-teal/10 text-teal-dark border-teal/30"
    },
    {
      id: 'synonyms-100',
      title: "100 ta \"oltin\" sinonim",
      countLabel: "100 ta so'z · B1 → C1",
      description: "Oddiy B1 darajadagi so'zlarni akademik C1 sinonimlariga aylantiring. Writing & Speaking boyitish uchun oltin lug'at.",
      sourceLabel: "B1 → C1",
      icon: <ArrowRightLeft className="w-5 h-5 text-clay" />,
      tagColor: "bg-clay/10 text-clay border-clay/30"
    },
    {
      id: 'gerund-infinitive-card',
      title: "Gerund & To-infinitive (Kartochka)",
      countLabel: "101 ta fe'l · 2 ta Qism",
      description: "Gerund (-ing) va To-infinitive qabul qiluvchi fe'llar. Har bir kartochka orqasida rasmdagi misol gaplar bilan.",
      sourceLabel: "Grammatika",
      icon: <Layers className="w-5 h-5 text-teal" />,
      tagColor: "bg-teal/10 text-teal-dark border-teal/30"
    },
    {
      id: 'gerund-infinitive-typing',
      title: "Gerund & To-infinitive (Yozib o'rganish)",
      countLabel: "101 ta gap · 3 ta rejim",
      description: "Bo'shliqni to'ldirish, gapni noldan yozish va matnni aniq ko'chirib yozish orqali grammatikani avtomatlashtirish.",
      sourceLabel: "Yozma mashq",
      icon: <Keyboard className="w-5 h-5 text-gold" />,
      tagColor: "bg-gold/20 text-ink border-gold/40"
    }
  ];

  return (
    <div className="max-w-5xl mx-auto px-3 sm:px-6 py-6 pb-16">
      {/* Top Banner / Branding */}
      <header className="retro-card bg-paper2 p-4 sm:p-6 mb-6">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4 text-center sm:text-left">
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-md border-1.5 border-ink overflow-hidden shadow-retro bg-white shrink-0">
              <img src="/logo.jpg" alt="Logo" className="w-full h-full object-cover" />
            </div>
            <div>
              <div className="inline-block px-2 py-0.5 border border-ink rounded bg-white text-[10px] font-mono uppercase font-bold text-teal-dark tracking-wider">
                AT with Jaxongir
              </div>
              <h1 className="text-xl sm:text-2xl font-bold font-serif text-ink mt-0.5">
                Jaxongir English Games
              </h1>
              <p className="text-xs font-mono text-ink/70">
                7 ta mustaqil so'z boyligi va grammatika moduli
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenIntro}
              title="Intro sahifasini ko'rish"
              className="retro-btn bg-white hover:bg-paper px-3 py-2 text-xs font-mono font-semibold flex items-center gap-1.5 cursor-pointer text-ink"
            >
              <Info className="w-3.5 h-3.5 text-teal" />
              <span>Kirish</span>
            </button>
          </div>
        </div>
      </header>

      {/* Grid of 7 games */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5">
        {games.map((g, idx) => (
          <div
            key={g.id}
            onClick={() => onSelectGame(g.id)}
            className="retro-card p-5 cursor-pointer hover:-translate-y-0.5 hover:shadow-retro-lg transition-all flex flex-col justify-between group"
          >
            <div>
              {/* Header row */}
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded border border-ink/40 bg-paper2 shadow-retro-sm">
                    {g.icon}
                  </div>
                  <div>
                    <span className="font-mono text-xs text-ink/60 font-semibold">
                      #{idx + 1}
                    </span>
                    <h2 className="text-base sm:text-lg font-bold font-serif text-ink group-hover:text-teal transition-colors leading-tight">
                      {g.title}
                    </h2>
                  </div>
                </div>

                <span className={`px-2 py-0.5 rounded text-[11px] font-mono border ${g.tagColor} shrink-0`}>
                  {g.sourceLabel}
                </span>
              </div>

              {/* Description */}
              <p className="text-xs sm:text-sm text-ink/80 font-serif leading-relaxed mt-2">
                {g.description}
              </p>
            </div>

            {/* Bottom Row */}
            <div className="pt-4 mt-3 border-t border-line/60 flex items-center justify-between">
              <span className="font-mono text-xs font-bold text-ink/70">
                {g.countLabel}
              </span>
              <span className="text-xs font-serif font-bold text-teal group-hover:translate-x-1 transition-transform inline-flex items-center gap-1">
                Boshlash →
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Bottom info banner */}
      <footer className="mt-8 text-center text-xs font-mono text-ink/60">
        <p>Barcha o'zgarishlar brauzer xotirasida (localStorage) avtomatik saqlanadi.</p>
        <p className="mt-1">Ilova to'liq oflayn ishlaydi.</p>
      </footer>
    </div>
  );
};
