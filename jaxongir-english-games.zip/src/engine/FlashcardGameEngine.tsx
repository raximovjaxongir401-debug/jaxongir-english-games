import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { GameConfig, FlashcardWord } from '../types';
import { loadGameData, saveGameData, resetGameData } from '../utils/storage';
import { checkAnswerMatch, normalizeText } from '../utils/textNormalizer';
import confetti from 'canvas-confetti';
import {
  ArrowLeft,
  Volume2,
  Shuffle,
  RotateCcw,
  Check,
  X,
  Search,
  Plus,
  Trash2,
  Clock,
  Sparkles,
  ArrowRightLeft,
  HelpCircle
} from 'lucide-react';

interface FlashcardGameEngineProps {
  config: GameConfig;
  onBackToDashboard: () => void;
}

type TabType = 'cards' | 'match' | 'quiz' | 'typing' | 'list' | 'edit';

export const FlashcardGameEngine: React.FC<FlashcardGameEngineProps> = ({
  config,
  onBackToDashboard
}) => {
  // 1. Data state persisted in localStorage
  const [words, setWords] = useState<FlashcardWord[]>(() => {
    return loadGameData(config.storageKey, config.initialData);
  });

  // Translation Direction: 'EN_UZ' or 'UZ_EN'
  const [direction, setDirection] = useState<'EN_UZ' | 'UZ_EN'>('EN_UZ');

  // Active Tab
  const [activeTab, setActiveTab] = useState<TabType>('cards');

  // Available unique units
  const availableUnits = useMemo(() => {
    const set = new Set<string | number>();
    words.forEach(w => set.add(w.unit));
    return Array.from(set).sort((a, b) => {
      const numA = typeof a === 'number' ? a : parseInt(String(a).replace(/\D/g, ''), 10) || 0;
      const numB = typeof b === 'number' ? b : parseInt(String(b).replace(/\D/g, ''), 10) || 0;
      return numA - numB;
    });
  }, [words]);

  // Selected Unit Filters ('all' or array of unit keys)
  const [selectedUnits, setSelectedUnits] = useState<(string | number)[]>([]);

  // Filtered words
  const filteredWords = useMemo(() => {
    if (selectedUnits.length === 0) return words;
    const unitSet = new Set(selectedUnits.map(String));
    return words.filter(w => unitSet.has(String(w.unit)));
  }, [words, selectedUnits]);

  // Reset helper when direction or unit filter changes
  const [engineNonce, setEngineNonce] = useState(0);
  const resetEngineState = useCallback(() => {
    setEngineNonce(n => n + 1);
  }, []);

  // Handle unit chip toggle
  const toggleUnit = (unit: string | number) => {
    setSelectedUnits(prev => {
      const exists = prev.includes(unit);
      if (exists) {
        // If it's the last selected one, don't allow unselecting all
        if (prev.length === 1) return prev;
        return prev.filter(u => u !== unit);
      } else {
        return [...prev, unit];
      }
    });
    resetEngineState();
  };

  const selectAllUnits = () => {
    setSelectedUnits([]);
    resetEngineState();
  };

  const toggleDirection = () => {
    setDirection(d => (d === 'EN_UZ' ? 'UZ_EN' : 'EN_UZ'));
    resetEngineState();
  };

  // Helper for text speech
  const speakText = (text: string, lang = 'en-US') => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang;
    utterance.rate = 0.9;
    window.speechSynthesis.speak(utterance);
  };

  // Format unit label
  const formatUnitChip = (u: string | number) => {
    if (config.unitChipFormat) return config.unitChipFormat(u);
    if (config.unitNames && config.unitNames[u]) {
      return `${u}: ${config.unitNames[u]}`;
    }
    const prefix = config.unitLabelPrefix || 'Unit';
    return `${prefix} ${u}`;
  };

  return (
    <div className="max-w-4xl mx-auto px-3 sm:px-6 py-4 pb-16">
      {/* Top Navigation Bar */}
      <div className="flex items-center justify-between gap-2 mb-3">
        <button
          onClick={onBackToDashboard}
          className="retro-btn bg-white hover:bg-paper2 px-3 py-1.5 text-xs font-mono font-bold flex items-center gap-1.5 cursor-pointer text-ink"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Bosh sahifa</span>
        </button>

        <button
          onClick={toggleDirection}
          className="retro-btn bg-gold hover:bg-gold-light text-ink px-3 py-1.5 text-xs font-mono font-bold flex items-center gap-1.5 cursor-pointer shadow-retro-sm"
          title="Tarjima yo'nalishini almashtirish"
        >
          <ArrowRightLeft className="w-3.5 h-3.5" />
          <span>
            {direction === 'EN_UZ'
              ? (config.directionLabelEN_UZ || 'EN → UZ')
              : (config.directionLabelUZ_EN || 'UZ → EN')}
          </span>
        </button>
      </div>

      {/* Game Header */}
      <div className="retro-card bg-paper2 p-4 mb-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold font-serif text-teal-dark">
              {config.title}
            </h1>
            <p className="text-xs text-ink/75 font-serif mt-0.5">
              {config.description}
            </p>
          </div>
          <div className="flex items-center gap-2 self-start sm:self-center shrink-0">
            <span className="font-mono text-xs px-2.5 py-1 bg-white border border-ink rounded font-bold text-teal shadow-retro-sm">
              {filteredWords.length} ta so'z
            </span>
          </div>
        </div>

        {/* Dynamic Unit Filter Chips */}
        <div className="mt-3 pt-3 border-t border-line/60">
          <div className="flex items-center gap-1.5 mb-1.5">
            <span className="text-[11px] font-mono text-ink/70 font-semibold uppercase">
              Bo'limlar filtri:
            </span>
          </div>
          <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto p-1">
            <button
              onClick={selectAllUnits}
              className={`px-2.5 py-1 text-xs font-mono font-bold rounded border transition-all cursor-pointer ${
                selectedUnits.length === 0
                  ? 'bg-teal text-paper border-ink shadow-retro-sm'
                  : 'bg-white text-ink border-ink/40 hover:bg-paper'
              }`}
            >
              Barchasi ({words.length})
            </button>
            {availableUnits.map(unit => {
              const isSelected = selectedUnits.includes(unit);
              const count = words.filter(w => String(w.unit) === String(unit)).length;
              return (
                <button
                  key={String(unit)}
                  onClick={() => toggleUnit(unit)}
                  className={`px-2.5 py-1 text-xs font-mono font-bold rounded border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-teal text-paper border-ink shadow-retro-sm'
                      : 'bg-white text-ink border-ink/40 hover:bg-paper'
                  }`}
                >
                  {formatUnitChip(unit)} ({count})
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex border-b-2 border-ink mb-5 overflow-x-auto gap-1">
        {[
          { id: 'cards', label: 'Kartochkalar' },
          { id: 'match', label: 'Moslashtirish' },
          { id: 'quiz', label: 'Tezkor test' },
          { id: 'typing', label: 'Yozib mashq' },
          { id: 'list', label: "Ro'yxat" },
          { id: 'edit', label: 'Tahrirlash' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as TabType)}
            className={`px-3 py-2 text-xs sm:text-sm font-serif font-bold border-t-2 border-l-2 border-r-2 border-ink rounded-t-md transition-all cursor-pointer whitespace-nowrap ${
              activeTab === tab.id
                ? 'bg-paper text-ink -mb-[2px] pb-[10px] border-b-2 border-b-paper font-black text-teal-dark shadow-retro-sm'
                : 'bg-paper2 text-ink/70 hover:bg-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Panels */}
      {filteredWords.length === 0 ? (
        <div className="retro-card p-8 text-center text-ink/80 font-serif">
          Tanlangan bo'limda so'zlar topilmadi. Iltimos, boshqa bo'limni tanlang.
        </div>
      ) : (
        <>
          {activeTab === 'cards' && (
            <FlashcardMode
              key={`cards-${engineNonce}-${direction}`}
              words={filteredWords}
              direction={direction}
              config={config}
              onSpeak={speakText}
            />
          )}

          {activeTab === 'match' && (
            <MatchingMode
              key={`match-${engineNonce}-${direction}`}
              words={filteredWords}
              direction={direction}
            />
          )}

          {activeTab === 'quiz' && (
            <QuizMode
              key={`quiz-${engineNonce}-${direction}`}
              words={filteredWords}
              direction={direction}
            />
          )}

          {activeTab === 'typing' && (
            <TypingMode
              key={`typing-${engineNonce}-${direction}`}
              words={filteredWords}
              direction={direction}
              config={config}
            />
          )}

          {activeTab === 'list' && (
            <WordListMode
              words={filteredWords}
              config={config}
              onSpeak={speakText}
            />
          )}

          {activeTab === 'edit' && (
            <EditDashboardMode
              words={words}
              config={config}
              onSaveWords={newWords => {
                setWords(newWords);
                saveGameData(config.storageKey, newWords);
              }}
              onResetToOriginal={() => {
                const orig = resetGameData(config.storageKey, config.initialData);
                setWords(orig);
              }}
            />
          )}
        </>
      )}
    </div>
  );
};

// ============================================================================
// MODE A: FLASHCARDS (3D FLIP)
// ============================================================================
interface FlashcardModeProps {
  words: FlashcardWord[];
  direction: 'EN_UZ' | 'UZ_EN';
  config: GameConfig;
  onSpeak: (text: string) => void;
}

const FlashcardMode: React.FC<FlashcardModeProps> = ({
  words,
  direction,
  config,
  onSpeak
}) => {
  const [deck, setDeck] = useState<FlashcardWord[]>(words);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [knownIds, setKnownIds] = useState<Set<number>>(new Set());

  useEffect(() => {
    setDeck(words);
    setCurrentIndex(0);
    setIsFlipped(false);
  }, [words]);

  const currentWord = deck[currentIndex] || deck[0];

  const handleNext = () => {
    setIsFlipped(false);
    setCurrentIndex(prev => (prev + 1) % deck.length);
  };

  const handlePrev = () => {
    setIsFlipped(false);
    setCurrentIndex(prev => (prev - 1 + deck.length) % deck.length);
  };

  const handleKnown = () => {
    if (currentWord) {
      setKnownIds(prev => new Set(prev).add(currentWord.id));
    }
    handleNext();
  };

  const handleShuffle = () => {
    const shuffled = [...deck].sort(() => Math.random() - 0.5);
    setDeck(shuffled);
    setCurrentIndex(0);
    setIsFlipped(false);
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setIsFlipped(false);
    setKnownIds(new Set());
  };

  // Keyboard navigation: Enter / Space = flip, Arrows = prev/next
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.code === 'Space' || e.code === 'Enter') {
        e.preventDefault();
        setIsFlipped(f => !f);
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        handleNext();
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        handlePrev();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [deck.length]);

  if (!currentWord) return null;

  const questionText = direction === 'EN_UZ' ? currentWord.en : currentWord.uz;
  const answerText = direction === 'EN_UZ' ? currentWord.uz : currentWord.en;
  const isEnglishPrompt = direction === 'EN_UZ';

  return (
    <div className="flex flex-col items-center select-none">
      {/* Status Bar */}
      <div className="w-full max-w-lg flex items-center justify-between mb-3 text-xs font-mono">
        <span className="font-bold text-ink">
          {currentIndex + 1} / {deck.length}
        </span>
        <span className="px-2 py-0.5 rounded bg-success/15 text-success font-bold border border-success/30">
          Bilaman: {knownIds.size} / {deck.length}
        </span>
      </div>

      {/* 3D Flip Card Container */}
      <div
        className="w-full max-w-lg h-72 sm:h-80 perspective-1000 cursor-pointer"
        onClick={() => setIsFlipped(!isFlipped)}
      >
        <div
          className={`relative w-full h-full transform-style-3d transition-transform duration-500 ${
            isFlipped ? 'rotate-y-180' : ''
          }`}
        >
          {/* FRONT */}
          <div className="absolute inset-0 backface-hidden retro-card p-6 flex flex-col justify-between bg-white">
            <div className="flex items-center justify-between">
              <span className="px-2 py-0.5 rounded bg-paper2 border border-ink/40 text-[11px] font-mono font-bold text-teal-dark">
                {config.unitLabelPrefix} {currentWord.unit}
              </span>
              <span className="text-[11px] font-mono text-ink/50 italic flex items-center gap-1">
                <span>bosing — tarjimasini ko'rish</span>
              </span>
            </div>

            <div className="flex flex-col items-center justify-center my-auto px-4 text-center">
              <h2 className="text-2xl sm:text-3xl font-serif font-bold text-ink mb-2">
                {questionText}
              </h2>
              {isEnglishPrompt && (
                <button
                  onClick={e => {
                    e.stopPropagation();
                    onSpeak(currentWord.en);
                  }}
                  className="p-1.5 rounded-full hover:bg-paper2 text-teal border border-transparent hover:border-ink/20 transition-all"
                  title="Talaffuzni tinglash"
                >
                  <Volume2 className="w-5 h-5" />
                </button>
              )}
            </div>

            <div className="text-center text-[10px] font-mono text-ink/40">
              [Enter / Space] — aylantirish · [← / →] — o'tish
            </div>
          </div>

          {/* BACK */}
          <div className="absolute inset-0 backface-hidden rotate-y-180 retro-card p-6 flex flex-col justify-between bg-paper2">
            <div className="flex items-center justify-between">
              <span className="px-2 py-0.5 rounded bg-white border border-ink/40 text-[11px] font-mono font-bold text-teal-dark">
                Tarjima
              </span>
              {!isEnglishPrompt && (
                <button
                  onClick={e => {
                    e.stopPropagation();
                    onSpeak(currentWord.en);
                  }}
                  className="p-1.5 rounded-full hover:bg-white text-teal transition-all"
                  title="Talaffuzni tinglash"
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              )}
            </div>

            <div className="flex flex-col items-center justify-center my-auto px-4 text-center">
              <h2 className="text-xl sm:text-2xl font-serif font-bold text-teal-dark mb-2">
                {answerText}
              </h2>

              {/* Optional tr field (example sentence or note) */}
              {config.showTrOnCardBack && currentWord.tr && (
                <div className="mt-2 p-2 bg-white/70 border border-line rounded text-xs font-serif italic text-ink/80 max-w-sm">
                  {config.trLabel && (
                    <span className="font-mono not-italic font-bold text-[10px] text-teal-dark block mb-0.5">
                      {config.trLabel}:
                    </span>
                  )}
                  "{currentWord.tr}"
                </div>
              )}
            </div>

            <div className="text-center text-[10px] font-mono text-ink/40">
              Qaytish uchun bosing
            </div>
          </div>
        </div>
      </div>

      {/* Main Control Scheme */}
      <div className="w-full max-w-lg grid grid-cols-4 gap-2 mt-5">
        <button
          onClick={handleNext}
          className="retro-btn py-2.5 px-2 bg-clay text-paper font-serif font-bold text-xs sm:text-sm cursor-pointer shadow-retro-sm text-center"
        >
          Bilmadim
        </button>

        <button
          onClick={handlePrev}
          className="retro-btn py-2.5 px-2 bg-white text-ink font-serif font-bold text-xs sm:text-sm cursor-pointer shadow-retro-sm text-center"
        >
          ← Oldingi
        </button>

        <button
          onClick={handleNext}
          className="retro-btn py-2.5 px-2 bg-white text-ink font-serif font-bold text-xs sm:text-sm cursor-pointer shadow-retro-sm text-center"
        >
          Keyingi →
        </button>

        <button
          onClick={handleKnown}
          className="retro-btn py-2.5 px-2 bg-success text-paper font-serif font-bold text-xs sm:text-sm cursor-pointer shadow-retro-sm text-center"
        >
          Bilaman ✓
        </button>
      </div>

      {/* Utility Bar */}
      <div className="w-full max-w-lg flex items-center justify-between mt-4 pt-3 border-t border-line/60">
        <button
          onClick={handleShuffle}
          className="text-xs font-mono font-semibold text-ink/80 hover:text-teal flex items-center gap-1 cursor-pointer"
        >
          <Shuffle className="w-3.5 h-3.5" />
          <span>Aralashtirish</span>
        </button>

        <button
          onClick={handleRestart}
          className="text-xs font-mono font-semibold text-ink/80 hover:text-clay flex items-center gap-1 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Boshidan</span>
        </button>
      </div>
    </div>
  );
};

// ============================================================================
// MODE B: MATCHING (MOSLASHTIRISH - 6 PAIRS / 12 TILES)
// ============================================================================
interface Tile {
  id: string; // unique tile id
  wordId: number;
  text: string;
  side: 'left' | 'right';
  isMatched: boolean;
}

interface MatchingModeProps {
  words: FlashcardWord[];
  direction: 'EN_UZ' | 'UZ_EN';
}

const MatchingMode: React.FC<MatchingModeProps> = ({ words, direction }) => {
  const [deck, setDeck] = useState<FlashcardWord[]>([]);
  const [poolIndex, setPoolIndex] = useState(0);
  const [tiles, setTiles] = useState<Tile[]>([]);
  const [selectedTile, setSelectedTile] = useState<Tile | null>(null);
  const [wrongPairIds, setWrongPairIds] = useState<string[]>([]);
  const [attempts, setAttempts] = useState(0);
  const [correctMatches, setCorrectMatches] = useState(0);

  // Initialize pool of words
  useEffect(() => {
    const shuffled = [...words].sort(() => Math.random() - 0.5);
    setDeck(shuffled);
    setPoolIndex(0);
    setAttempts(0);
    setCorrectMatches(0);
  }, [words]);

  // Load next 6 pairs
  const loadNextBatch = useCallback((startIndex: number, currentDeck: FlashcardWord[]) => {
    if (currentDeck.length === 0) return;
    const batchSize = Math.min(6, currentDeck.length);
    let chosenWords = currentDeck.slice(startIndex, startIndex + batchSize);
    if (chosenWords.length < 6 && currentDeck.length >= 6) {
      // Loop back if needed
      chosenWords = [...chosenWords, ...currentDeck.slice(0, 6 - chosenWords.length)];
    }

    const newTiles: Tile[] = [];
    chosenWords.forEach(w => {
      const leftText = direction === 'EN_UZ' ? w.en : w.uz;
      const rightText = direction === 'EN_UZ' ? w.uz : w.en;

      newTiles.push({
        id: `left-${w.id}`,
        wordId: w.id,
        text: leftText,
        side: 'left',
        isMatched: false
      });
      newTiles.push({
        id: `right-${w.id}`,
        wordId: w.id,
        text: rightText,
        side: 'right',
        isMatched: false
      });
    });

    // Shuffle tiles
    setTiles(newTiles.sort(() => Math.random() - 0.5));
    setSelectedTile(null);
    setWrongPairIds([]);
  }, [direction]);

  useEffect(() => {
    if (deck.length > 0) {
      loadNextBatch(poolIndex, deck);
    }
  }, [deck, poolIndex, loadNextBatch]);

  const handleTileClick = (tile: Tile) => {
    if (tile.isMatched || wrongPairIds.length > 0) return;

    // First tile selection
    if (!selectedTile) {
      setSelectedTile(tile);
      return;
    }

    // Clicking the same tile deselects it
    if (selectedTile.id === tile.id) {
      setSelectedTile(null);
      return;
    }

    // If clicked another tile on the same side, switch selection to that tile
    if (selectedTile.side === tile.side) {
      setSelectedTile(tile);
      return;
    }

    // User selected one tile from each side!
    setAttempts(a => a + 1);

    if (selectedTile.wordId === tile.wordId) {
      // MATCH SUCCESS!
      setCorrectMatches(c => c + 1);
      setTiles(prev =>
        prev.map(t =>
          t.wordId === tile.wordId ? { ...t, isMatched: true } : t
        )
      );
      setSelectedTile(null);

      // Check if all 6 pairs matched
      const remainingUnmatched = tiles.filter(
        t => !t.isMatched && t.wordId !== tile.wordId
      );

      if (remainingUnmatched.length === 0) {
        // Round complete!
        confetti({ particleCount: 40, spread: 60, origin: { y: 0.6 } });
        setTimeout(() => {
          setPoolIndex(prev => (prev + 6 >= deck.length ? 0 : prev + 6));
        }, 700);
      }
    } else {
      // WRONG PAIR
      const wrongIds = [selectedTile.id, tile.id];
      setWrongPairIds(wrongIds);
      setSelectedTile(null);

      setTimeout(() => {
        setWrongPairIds([]);
      }, 550);
    }
  };

  const handleReshuffleBatch = () => {
    loadNextBatch(poolIndex, deck);
  };

  const remainingPairs = tiles.filter(t => !t.isMatched).length / 2;

  return (
    <div className="flex flex-col items-center">
      {/* Counters */}
      <div className="w-full max-w-xl flex items-center justify-between mb-4 text-xs font-mono">
        <span className="font-bold text-ink">
          Qolgan: <span className="text-teal font-extrabold">{remainingPairs}</span> juftlik
        </span>
        <span className="px-2.5 py-1 bg-white border border-ink rounded font-bold text-ink shadow-retro-sm">
          To'g'ri: {correctMatches} / Urinishlar: {attempts}
        </span>
      </div>

      {/* 12 Tiles Grid */}
      <div className="w-full max-w-xl grid grid-cols-2 sm:grid-cols-3 gap-2.5">
        {tiles.map(tile => {
          const isSelected = selectedTile?.id === tile.id;
          const isWrong = wrongPairIds.includes(tile.id);

          let tileStyle = 'bg-white text-ink border-ink hover:bg-paper2';
          if (tile.isMatched) {
            tileStyle = 'bg-success/20 text-success border-success/40 opacity-40 cursor-not-allowed line-through';
          } else if (isWrong) {
            tileStyle = 'bg-danger text-white border-ink shadow-retro-pressed animate-shake';
          } else if (isSelected) {
            tileStyle = 'bg-gold text-ink border-ink font-bold shadow-retro-sm scale-[0.98]';
          }

          return (
            <button
              key={tile.id}
              disabled={tile.isMatched}
              onClick={() => handleTileClick(tile)}
              className={`p-3 sm:p-4 rounded-md border-1.5 font-serif text-xs sm:text-sm text-center flex items-center justify-center min-h-[68px] transition-all cursor-pointer ${tileStyle}`}
            >
              <span className="break-words line-clamp-3 leading-snug">{tile.text}</span>
            </button>
          );
        })}
      </div>

      {/* Bottom control */}
      <div className="w-full max-w-xl flex justify-center mt-5">
        <button
          onClick={handleReshuffleBatch}
          className="retro-btn bg-white hover:bg-paper2 px-4 py-2 text-xs font-mono font-bold flex items-center gap-1.5 text-ink cursor-pointer"
        >
          <Shuffle className="w-3.5 h-3.5 text-teal" />
          <span>Yangi to'plam</span>
        </button>
      </div>
    </div>
  );
};

// ============================================================================
// MODE C: SPEED QUIZ (TEZKOR TEST - 15 QUESTIONS / 20 SECONDS EACH)
// ============================================================================
interface QuizQuestion {
  word: FlashcardWord;
  prompt: string;
  correctAnswer: string;
  options: string[];
}

interface QuizModeProps {
  words: FlashcardWord[];
  direction: 'EN_UZ' | 'UZ_EN';
}

const QuizMode: React.FC<QuizModeProps> = ({ words, direction }) => {
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [timeLeft, setTimeLeft] = useState(20);
  const [timerActive, setTimerActive] = useState(true);

  // Generate 15 questions
  const initQuiz = useCallback(() => {
    if (words.length === 0) return;
    const shuffled = [...words].sort(() => Math.random() - 0.5);
    const count = Math.min(15, shuffled.length);
    const selected = shuffled.slice(0, count);

    const generated: QuizQuestion[] = selected.map(w => {
      const prompt = direction === 'EN_UZ' ? w.en : w.uz;
      const correctAnswer = direction === 'EN_UZ' ? w.uz : w.en;

      // Pick 3 random wrong options from words with distinct text
      const otherAnswers = Array.from(
        new Set(
          words
            .filter(other => other.id !== w.id)
            .map(other => (direction === 'EN_UZ' ? other.uz : other.en))
            .filter(ans => ans.trim() !== correctAnswer.trim())
        )
      );

      const shuffledOthers = otherAnswers.sort(() => Math.random() - 0.5).slice(0, 3);
      const options = [correctAnswer, ...shuffledOthers].sort(() => Math.random() - 0.5);

      return {
        word: w,
        prompt,
        correctAnswer,
        options
      };
    });

    setQuestions(generated);
    setCurrentIndex(0);
    setScore(0);
    setIsFinished(false);
    setSelectedOption(null);
    setTimeLeft(20);
    setTimerActive(true);
  }, [words, direction]);

  useEffect(() => {
    initQuiz();
  }, [initQuiz]);

  const currentQ = questions[currentIndex];

  const handleNextQuestion = useCallback((isCorrect: boolean) => {
    if (isCorrect) setScore(s => s + 1);

    setTimeout(() => {
      if (currentIndex + 1 < questions.length) {
        setCurrentIndex(i => i + 1);
        setSelectedOption(null);
        setTimeLeft(20);
        setTimerActive(true);
      } else {
        setIsFinished(true);
        setTimerActive(false);
        confetti({ particleCount: 70, spread: 70 });
      }
    }, 700);
  }, [currentIndex, questions.length]);

  // Countdown timer
  useEffect(() => {
    if (!timerActive || isFinished) return;
    if (timeLeft <= 0) {
      // Time out!
      setTimerActive(false);
      setSelectedOption('__TIMEOUT__');
      setTimeout(() => {
        handleNextQuestion(false);
      }, 1100);
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft(t => t - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [timeLeft, timerActive, isFinished, handleNextQuestion]);

  const handleSelectOption = (option: string) => {
    if (selectedOption !== null || !timerActive) return;
    setTimerActive(false);
    setSelectedOption(option);
    const isCorrect = option === currentQ.correctAnswer;
    handleNextQuestion(isCorrect);
  };

  if (isFinished) {
    const percentage = Math.round((score / questions.length) * 100) || 0;
    return (
      <div className="retro-card p-6 sm:p-8 max-w-md mx-auto text-center">
        <Sparkles className="w-12 h-12 text-gold mx-auto mb-3" />
        <h2 className="text-2xl font-serif font-bold text-ink mb-1">
          Test yakunlandi!
        </h2>
        <p className="text-sm font-mono text-ink/70 mb-4">
          Natijangiz: <span className="font-bold text-teal">{score} / {questions.length}</span> ({percentage}%)
        </p>

        <div className="w-full bg-paper2 h-3 rounded-full border border-ink overflow-hidden mb-6">
          <div
            className="bg-teal h-full transition-all duration-500"
            style={{ width: `${percentage}%` }}
          />
        </div>

        <button
          onClick={initQuiz}
          className="w-full py-3 bg-teal hover:bg-teal-dark text-paper font-serif font-bold rounded border-1.5 border-ink shadow-retro cursor-pointer"
        >
          Qayta boshlash
        </button>
      </div>
    );
  }

  if (!currentQ) return null;

  return (
    <div className="flex flex-col items-center max-w-lg mx-auto">
      {/* Quiz Progress & Timer */}
      <div className="w-full flex items-center justify-between mb-2 text-xs font-mono">
        <span className="font-bold text-ink">
          Savol {currentIndex + 1} / {questions.length}
        </span>
        <div className="flex items-center gap-1.5 font-bold">
          <Clock className="w-3.5 h-3.5 text-clay" />
          <span className={timeLeft <= 5 ? 'text-danger font-black animate-pulse' : 'text-ink'}>
            {timeLeft} soniya
          </span>
        </div>
      </div>

      {/* Timer Bar */}
      <div className="w-full bg-paper2 h-2 rounded-full border border-ink/40 overflow-hidden mb-4">
        <div
          className={`h-full transition-all duration-1000 ${
            timeLeft <= 5 ? 'bg-danger' : 'bg-teal'
          }`}
          style={{ width: `${(timeLeft / 20) * 100}%` }}
        />
      </div>

      {/* Question Card */}
      <div className="w-full retro-card p-6 text-center mb-4 bg-white">
        <span className="text-[11px] font-mono font-bold text-ink/50 uppercase block mb-1">
          Tarjimasini tanlang:
        </span>
        <h2 className="text-2xl sm:text-3xl font-serif font-bold text-teal-dark">
          {currentQ.prompt}
        </h2>
      </div>

      {/* 4 Options */}
      <div className="w-full grid grid-cols-1 gap-2.5">
        {currentQ.options.map((option, idx) => {
          let btnStyle = 'bg-white text-ink border-ink hover:bg-paper2';
          if (selectedOption !== null) {
            if (option === currentQ.correctAnswer) {
              btnStyle = 'bg-success text-white border-ink font-bold shadow-retro-sm';
            } else if (option === selectedOption) {
              btnStyle = 'bg-danger text-white border-ink font-bold shadow-retro-sm';
            } else {
              btnStyle = 'bg-white/50 text-ink/40 border-ink/30 cursor-not-allowed';
            }
          }

          return (
            <button
              key={idx}
              disabled={selectedOption !== null}
              onClick={() => handleSelectOption(option)}
              className={`p-3.5 rounded-md border-1.5 font-serif text-sm sm:text-base text-left flex items-center justify-between transition-all cursor-pointer ${btnStyle}`}
            >
              <span>{option}</span>
              {selectedOption !== null && option === currentQ.correctAnswer && (
                <Check className="w-4 h-4 shrink-0" />
              )}
              {selectedOption !== null && option === selectedOption && option !== currentQ.correctAnswer && (
                <X className="w-4 h-4 shrink-0" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};

// ============================================================================
// MODE D: TYPING PRACTICE (YOZIB MASHQ - 20 QUESTIONS)
// ============================================================================
interface TypingModeProps {
  words: FlashcardWord[];
  direction: 'EN_UZ' | 'UZ_EN';
  config: GameConfig;
}

const TypingMode: React.FC<TypingModeProps> = ({ words, direction, config }) => {
  const [deck, setDeck] = useState<FlashcardWord[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userInput, setUserInput] = useState('');
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; text: string } | null>(null);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const initDeck = useCallback(() => {
    if (words.length === 0) return;
    const shuffled = [...words].sort(() => Math.random() - 0.5);
    setDeck(shuffled.slice(0, Math.min(20, shuffled.length)));
    setCurrentIndex(0);
    setUserInput('');
    setFeedback(null);
    setScore(0);
    setIsFinished(false);
  }, [words]);

  useEffect(() => {
    initDeck();
  }, [initDeck]);

  useEffect(() => {
    if (!feedback && inputRef.current) {
      inputRef.current.focus();
    }
  }, [currentIndex, feedback]);

  const currentWord = deck[currentIndex];

  const handleCheck = () => {
    if (!currentWord || feedback !== null) return;
    const target = direction === 'EN_UZ' ? currentWord.uz : currentWord.en;
    const isMatch = checkAnswerMatch(userInput, target);

    if (isMatch) {
      setScore(s => s + 1);
      setFeedback({ isCorrect: true, text: "To'g'ri! ✓" });
    } else {
      setFeedback({ isCorrect: false, text: `To'g'ri javob: ${target}` });
    }

    setTimeout(() => {
      if (currentIndex + 1 < deck.length) {
        setCurrentIndex(i => i + 1);
        setUserInput('');
        setFeedback(null);
      } else {
        setIsFinished(true);
        confetti({ particleCount: 60, spread: 60 });
      }
    }, 1100);
  };

  const handleSkip = () => {
    if (!currentWord || feedback !== null) return;
    const target = direction === 'EN_UZ' ? currentWord.uz : currentWord.en;
    setFeedback({ isCorrect: false, text: `To'g'ri javob: ${target}` });

    setTimeout(() => {
      if (currentIndex + 1 < deck.length) {
        setCurrentIndex(i => i + 1);
        setUserInput('');
        setFeedback(null);
      } else {
        setIsFinished(true);
      }
    }, 1100);
  };

  if (isFinished) {
    return (
      <div className="retro-card p-6 sm:p-8 max-w-md mx-auto text-center">
        <Sparkles className="w-12 h-12 text-gold mx-auto mb-2" />
        <h2 className="text-2xl font-serif font-bold text-ink mb-1">
          Yozish mashqi tugadi!
        </h2>
        <p className="text-sm font-mono text-ink/70 mb-4">
          To'g'ri javoblar: <span className="font-bold text-teal">{score} / {deck.length}</span>
        </p>
        <button
          onClick={initDeck}
          className="w-full py-3 bg-teal hover:bg-teal-dark text-paper font-serif font-bold rounded border-1.5 border-ink shadow-retro cursor-pointer"
        >
          Boshidan boshlash
        </button>
      </div>
    );
  }

  if (!currentWord) return null;

  const promptText = direction === 'EN_UZ' ? currentWord.en : currentWord.uz;

  return (
    <div className="max-w-lg mx-auto">
      {/* Status */}
      <div className="flex items-center justify-between mb-3 text-xs font-mono">
        <span className="font-bold text-ink">
          Savol {currentIndex + 1} / {deck.length}
        </span>
        <span className="font-bold text-teal">
          To'g'ri: {score}
        </span>
      </div>

      {/* Prompt Card */}
      <div className="retro-card p-6 text-center mb-4 bg-white">
        <span className="text-[11px] font-mono text-ink/60 uppercase block mb-1">
          {config.id === 'synonyms-100'
            ? direction === 'EN_UZ'
              ? 'AKADEMIK SINONIMINI YOZING (BITTASI YETARLI)'
              : 'ODDIY SO\'ZNI YOZING'
            : 'TARJIMASINI YOZING (VERGUL BILAN BO\'LSA BITTASI YETARLI):'}
        </span>
        <h2 className="text-2xl sm:text-3xl font-serif font-bold text-ink">
          {promptText}
        </h2>
      </div>

      {/* Input Form */}
      <form
        onSubmit={e => {
          e.preventDefault();
          handleCheck();
        }}
        className="flex flex-col gap-3"
      >
        <input
          ref={inputRef}
          type="text"
          value={userInput}
          disabled={feedback !== null}
          onChange={e => setUserInput(e.target.value)}
          placeholder="Javobni yozing..."
          className="w-full p-3.5 bg-white border-1.5 border-ink rounded-md font-serif text-base text-ink shadow-retro-sm outline-none focus:border-teal"
        />

        {/* Feedback Banner */}
        {feedback && (
          <div
            className={`p-3 rounded border-1.5 font-serif text-sm font-bold text-center ${
              feedback.isCorrect
                ? 'bg-success/20 text-success border-success'
                : 'bg-danger/20 text-danger border-danger'
            }`}
          >
            {feedback.text}
          </div>
        )}

        <div className="flex items-center gap-2 mt-1">
          <button
            type="submit"
            disabled={feedback !== null || !userInput.trim()}
            className="flex-1 py-3 bg-teal hover:bg-teal-dark active:translate-x-0.5 active:translate-y-0.5 text-paper font-serif font-bold text-sm rounded border-1.5 border-ink shadow-retro cursor-pointer disabled:opacity-50"
          >
            Tekshirish (Enter)
          </button>
          <button
            type="button"
            disabled={feedback !== null}
            onClick={handleSkip}
            className="px-4 py-3 bg-white hover:bg-paper2 text-ink/80 font-serif font-bold text-sm rounded border-1.5 border-ink shadow-retro cursor-pointer"
          >
            O'tkazib yuborish
          </button>
        </div>
      </form>
    </div>
  );
};

// ============================================================================
// MODE E: WORD LIST (RO'YXAT)
// ============================================================================
interface WordListModeProps {
  words: FlashcardWord[];
  config: GameConfig;
  onSpeak: (text: string) => void;
}

const WordListMode: React.FC<WordListModeProps> = ({ words, config, onSpeak }) => {
  const [search, setSearch] = useState('');

  const filtered = useMemo(() => {
    if (!search.trim()) return words;
    const q = normalizeText(search);
    return words.filter(
      w => normalizeText(w.en).includes(q) || normalizeText(w.uz).includes(q)
    );
  }, [words, search]);

  return (
    <div>
      {/* Search Bar */}
      <div className="relative mb-4">
        <Search className="w-4 h-4 text-ink/50 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Inglizcha yoki o'zbekcha qidiruv..."
          className="w-full pl-9 pr-3 py-2.5 bg-white border-1.5 border-ink rounded-md font-serif text-sm text-ink shadow-retro-sm outline-none focus:border-teal"
        />
      </div>

      {/* Words Directory Table */}
      <div className="retro-card overflow-hidden">
        <div className="overflow-x-auto max-h-[500px]">
          <table className="w-full text-left border-collapse font-serif text-xs sm:text-sm">
            <thead className="bg-paper2 border-b-1.5 border-ink font-mono text-[11px] text-ink/80 sticky top-0 z-10">
              <tr>
                <th className="py-2.5 px-3 border-r border-line">{config.unitLabelPrefix}</th>
                <th className="py-2.5 px-3 border-r border-line">{config.questionLabel || 'English'}</th>
                <th className="py-2.5 px-3">{config.answerLabel || "O'zbekcha"}</th>
                {config.showTrOnCardBack && (
                  <th className="py-2.5 px-3 border-l border-line hidden sm:table-cell">
                    {config.trLabel || "Qo'shimcha"}
                  </th>
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-line/60 bg-white">
              {filtered.map(w => (
                <tr key={w.id} className="hover:bg-paper2/50 transition-colors">
                  <td className="py-2 px-3 font-mono text-xs text-ink/70 border-r border-line/60 whitespace-nowrap">
                    {w.unit}
                  </td>
                  <td className="py-2 px-3 font-bold text-ink border-r border-line/60">
                    <div className="flex items-center justify-between gap-1">
                      <span>{w.en}</span>
                      <button
                        onClick={() => onSpeak(w.en)}
                        className="text-teal hover:text-teal-dark p-1"
                        title="Tinglash"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                  <td className="py-2 px-3 text-ink/90">
                    {w.uz}
                  </td>
                  {config.showTrOnCardBack && (
                    <td className="py-2 px-3 text-xs italic text-ink/70 border-l border-line/60 hidden sm:table-cell">
                      {w.tr || '—'}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// MODE F: MANAGEMENT DASHBOARD (TAHRIRLASH)
// ============================================================================
interface EditDashboardModeProps {
  words: FlashcardWord[];
  config: GameConfig;
  onSaveWords: (newWords: FlashcardWord[]) => void;
  onResetToOriginal: () => void;
}

const EditDashboardMode: React.FC<EditDashboardModeProps> = ({
  words,
  config,
  onSaveWords,
  onResetToOriginal
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [savedBadge, setSavedBadge] = useState(false);

  // New item form state
  const [newUnit, setNewUnit] = useState<string>('1');
  const [newEn, setNewEn] = useState('');
  const [newUz, setNewUz] = useState('');
  const [newTr, setNewTr] = useState('');

  const triggerSaveNotification = () => {
    setSavedBadge(true);
    setTimeout(() => setSavedBadge(false), 1500);
  };

  const handleAddWord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEn.trim() || !newUz.trim()) return;

    const unitVal = parseInt(newUnit, 10) || (newUnit.trim() ? newUnit.trim() : 1);
    const newEntry: FlashcardWord = {
      id: Date.now(),
      unit: unitVal,
      en: newEn.trim(),
      uz: newUz.trim(),
      ...(newTr.trim() ? { tr: newTr.trim() } : {})
    };

    const updated = [newEntry, ...words];
    onSaveWords(updated);
    setNewEn('');
    setNewUz('');
    setNewTr('');
    triggerSaveNotification();
  };

  const handleUpdateItem = (id: number, field: keyof FlashcardWord, value: string) => {
    const updated = words.map(w => {
      if (w.id === id) {
        if (field === 'unit') {
          const parsed = parseInt(value, 10);
          return { ...w, unit: isNaN(parsed) ? value : parsed };
        }
        return { ...w, [field]: value };
      }
      return w;
    });
    onSaveWords(updated);
    triggerSaveNotification();
  };

  const handleDeleteItem = (id: number) => {
    if (window.confirm("Haqiqatan ham bu so'zni o'chirmoqchimisiz?")) {
      const updated = words.filter(w => w.id !== id);
      onSaveWords(updated);
      triggerSaveNotification();
    }
  };

  const handleResetConfirm = () => {
    if (
      window.confirm(
        "Barcha o'zgarishlar o'chirilib, ilova bilan kelgan asl so'zlar ro'yxati tiklanadi. Davom etasizmi?"
      )
    ) {
      onResetToOriginal();
      triggerSaveNotification();
    }
  };

  const filteredWords = useMemo(() => {
    if (!searchTerm.trim()) return words;
    const q = normalizeText(searchTerm);
    return words.filter(
      w => normalizeText(w.en).includes(q) || normalizeText(w.uz).includes(q)
    );
  }, [words, searchTerm]);

  return (
    <div className="space-y-6">
      {/* Top Banner with Reset and Saved badge */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          {savedBadge && (
            <span className="px-2.5 py-1 rounded bg-success text-paper font-mono text-xs font-bold shadow-retro-sm animate-fade-in">
              Saqlandi ✓
            </span>
          )}
        </div>

        <button
          onClick={handleResetConfirm}
          className="retro-btn bg-white hover:bg-clay hover:text-white text-danger px-3 py-1.5 text-xs font-mono font-bold flex items-center gap-1 cursor-pointer transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Asl holatiga qaytarish</span>
        </button>
      </div>

      {/* Add New Word Form */}
      <div className="retro-card p-4 sm:p-5 bg-paper2">
        <h3 className="font-serif font-bold text-base text-ink mb-3 flex items-center gap-1.5">
          <Plus className="w-4 h-4 text-teal" />
          <span>Yangi so'z qo'shish</span>
        </h3>
        <form onSubmit={handleAddWord} className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
          <div>
            <label className="block text-[11px] font-mono text-ink/70 font-bold mb-1">
              {config.unitLabelPrefix} raqami
            </label>
            <input
              type="text"
              value={newUnit}
              onChange={e => setNewUnit(e.target.value)}
              placeholder="1"
              className="w-full p-2 bg-white border border-ink rounded font-mono text-xs outline-none focus:border-teal"
            />
          </div>

          <div>
            <label className="block text-[11px] font-mono text-ink/70 font-bold mb-1">
              {config.questionLabel || 'English'}
            </label>
            <input
              type="text"
              value={newEn}
              onChange={e => setNewEn(e.target.value)}
              placeholder="benefit"
              className="w-full p-2 bg-white border border-ink rounded font-serif text-xs outline-none focus:border-teal"
            />
          </div>

          <div>
            <label className="block text-[11px] font-mono text-ink/70 font-bold mb-1">
              {config.answerLabel || "O'zbekcha"}
            </label>
            <input
              type="text"
              value={newUz}
              onChange={e => setNewUz(e.target.value)}
              placeholder="foyda, naf"
              className="w-full p-2 bg-white border border-ink rounded font-serif text-xs outline-none focus:border-teal"
            />
          </div>

          <div className="flex items-end">
            <button
              type="submit"
              disabled={!newEn.trim() || !newUz.trim()}
              className="w-full py-2 bg-teal hover:bg-teal-dark active:translate-x-0.5 active:translate-y-0.5 text-paper font-serif font-bold text-xs rounded border border-ink shadow-retro-sm cursor-pointer disabled:opacity-50"
            >
              + Qo'shish
            </button>
          </div>
        </form>
      </div>

      {/* Editor Table */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-serif font-bold text-sm text-ink">
            Jami so'zlar: {words.length} ta
          </h3>
          <div className="w-48 sm:w-64">
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Tahrirlashda qidiruv..."
              className="w-full px-2.5 py-1.5 bg-white border border-ink rounded font-mono text-xs outline-none focus:border-teal"
            />
          </div>
        </div>

        <div className="retro-card overflow-hidden">
          <div className="overflow-x-auto max-h-[500px]">
            <table className="w-full text-left border-collapse font-serif text-xs">
              <thead className="bg-paper2 border-b-1.5 border-ink font-mono text-[11px] text-ink/80 sticky top-0 z-10">
                <tr>
                  <th className="py-2 px-2.5 w-16 border-r border-line">{config.unitLabelPrefix}</th>
                  <th className="py-2 px-2.5 border-r border-line">{config.questionLabel || 'English'}</th>
                  <th className="py-2 px-2.5 border-r border-line">{config.answerLabel || "O'zbekcha"}</th>
                  <th className="py-2 px-2 w-14 text-center">Amal</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line/60 bg-white">
                {filteredWords.map(w => (
                  <tr key={w.id} className="hover:bg-paper2/40">
                    <td className="p-1.5 border-r border-line/60">
                      <input
                        type="text"
                        defaultValue={String(w.unit)}
                        onBlur={e => handleUpdateItem(w.id, 'unit', e.target.value)}
                        className="w-full p-1 bg-transparent border border-transparent hover:border-ink/30 focus:border-teal rounded font-mono text-xs"
                      />
                    </td>
                    <td className="p-1.5 border-r border-line/60">
                      <input
                        type="text"
                        defaultValue={w.en}
                        onBlur={e => handleUpdateItem(w.id, 'en', e.target.value)}
                        className="w-full p-1 bg-transparent border border-transparent hover:border-ink/30 focus:border-teal rounded font-serif text-xs font-bold"
                      />
                    </td>
                    <td className="p-1.5 border-r border-line/60">
                      <input
                        type="text"
                        defaultValue={w.uz}
                        onBlur={e => handleUpdateItem(w.id, 'uz', e.target.value)}
                        className="w-full p-1 bg-transparent border border-transparent hover:border-ink/30 focus:border-teal rounded font-serif text-xs"
                      />
                    </td>
                    <td className="p-1.5 text-center">
                      <button
                        onClick={() => handleDeleteItem(w.id)}
                        className="p-1 text-danger hover:bg-danger/10 rounded cursor-pointer transition-colors"
                        title="O'chirish"
                      >
                        <Trash2 className="w-3.5 h-3.5 mx-auto" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
