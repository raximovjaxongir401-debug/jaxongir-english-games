import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { SentenceItem, StudyMode } from '../types';
import rawSentencesData from '../data/gerund-infinitive-sentences.json';
import {
  normalizeText,
  compareSentenceWords,
  generateLetterHint
} from '../utils/textNormalizer';
import confetti from 'canvas-confetti';
import {
  ArrowLeft,
  Sparkles,
  Eye,
  EyeOff,
  Lightbulb,
  RotateCcw,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Volume2
} from 'lucide-react';

interface Game7TypingSentencesProps {
  onBackToDashboard: () => void;
}

export const Game7TypingSentences: React.FC<Game7TypingSentencesProps> = ({
  onBackToDashboard
}) => {
  const allSentences: SentenceItem[] = rawSentencesData as SentenceItem[];

  // Two modules: 'G' (46 items) or 'I' (55 items)
  const [activeModule, setActiveModule] = useState<'G' | 'I'>('G');

  // Study mode: 'fill' | 'sentence' | 'copy'
  const [studyMode, setStudyMode] = useState<StudyMode>('fill');

  // Filtered pool
  const modulePool = useMemo(() => {
    return allSentences.filter(s => s.p === activeModule);
  }, [allSentences, activeModule]);

  // Queue of sentences for current session
  const [queue, setQueue] = useState<SentenceItem[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  // Results tracking
  const [score, setScore] = useState(0);
  const [failedItems, setFailedItems] = useState<SentenceItem[]>([]);
  const [isSessionFinished, setIsSessionFinished] = useState(false);

  // Common UI states
  const [showTranslation, setShowTranslation] = useState(true);

  // --- MODE 1: Fill the blanks state ---
  const [fillInput, setFillInput] = useState('');
  const [fillFeedback, setFillFeedback] = useState<{
    submitted: boolean;
    isCorrect: boolean;
    warningMsg?: string;
  } | null>(null);

  // --- MODE 2: Write sentence state ---
  const [sentenceInput, setSentenceInput] = useState('');
  const [sentenceSubmitted, setSentenceSubmitted] = useState(false);
  const [showLetterHint, setShowLetterHint] = useState(false);

  // --- MODE 3: Copy type state ---
  const [copyInput, setCopyInput] = useState('');
  const [copyHadError, setCopyHadError] = useState(false);
  const [copySubmitted, setCopySubmitted] = useState(false);

  // Input ref
  const activeInputRef = useRef<HTMLInputElement | HTMLTextAreaElement>(null);

  // Start / restart session
  const startSession = useCallback(
    (itemsToUse: SentenceItem[]) => {
      const shuffled = [...itemsToUse].sort(() => Math.random() - 0.5);
      setQueue(shuffled);
      setCurrentIndex(0);
      setScore(0);
      setFailedItems([]);
      setIsSessionFinished(false);

      // Reset mode states
      setFillInput('');
      setFillFeedback(null);
      setSentenceInput('');
      setSentenceSubmitted(false);
      setShowLetterHint(false);
      setCopyInput('');
      setCopyHadError(false);
      setCopySubmitted(false);
    },
    []
  );

  // When module changes, restart session with that module's pool
  useEffect(() => {
    startSession(modulePool);
  }, [modulePool, startSession]);

  // When study mode changes, restart current module session
  useEffect(() => {
    startSession(modulePool);
  }, [studyMode, modulePool, startSession]);

  // Focus input on question change
  useEffect(() => {
    if (!isSessionFinished && activeInputRef.current) {
      activeInputRef.current.focus();
    }
  }, [currentIndex, isSessionFinished, fillFeedback, sentenceSubmitted]);

  const currentItem = queue[currentIndex];

  // Parse sentence with [[target]]
  const parsedSentence = useMemo(() => {
    if (!currentItem) return { pre: '', target: '', post: '', fullText: '' };
    const regex = /^(.*?)\[\[(.*?)\]\](.*)$/;
    const match = currentItem.s.match(regex);
    if (match) {
      return {
        pre: match[1],
        target: match[2],
        post: match[3],
        fullText: `${match[1]}${match[2]}${match[3]}`
      };
    }
    return {
      pre: '',
      target: currentItem.b,
      post: '',
      fullText: currentItem.s
    };
  }, [currentItem]);

  // Speech helper
  const speakText = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utt = new SpeechSynthesisUtterance(text);
    utt.lang = 'en-US';
    window.speechSynthesis.speak(utt);
  };

  // Advance to next question or finish session
  const advanceToNext = (wasCorrect: boolean) => {
    if (wasCorrect) {
      setScore(s => s + 1);
    } else {
      setFailedItems(prev => [...prev, currentItem]);
    }

    if (currentIndex + 1 < queue.length) {
      setCurrentIndex(i => i + 1);
      // Reset inputs
      setFillInput('');
      setFillFeedback(null);
      setSentenceInput('');
      setSentenceSubmitted(false);
      setShowLetterHint(false);
      setCopyInput('');
      setCopyHadError(false);
      setCopySubmitted(false);
    } else {
      setIsSessionFinished(true);
      if (wasCorrect && score + 1 === queue.length) {
        confetti({ particleCount: 80, spread: 80 });
      } else if (score >= queue.length * 0.7) {
        confetti({ particleCount: 50, spread: 60 });
      }
    }
  };

  // -------------------------------------------------------------
  // MODE 1 HANDLERS (Bo'shliqni to'ldiring)
  // -------------------------------------------------------------
  const handleFillSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!currentItem || fillFeedback?.submitted) return;

    const userAns = normalizeText(fillInput);
    const targetAns = normalizeText(parsedSentence.target);

    // Smart warnings check:
    let warningMsg: string | undefined;
    if (activeModule === 'I' && !userAns.startsWith('to ') && userAns === normalizeText(currentItem.b)) {
      warningMsg = "'to' ni unutdingiz!";
    } else if (activeModule === 'G' && userAns.startsWith('to ')) {
      warningMsg = "Bu yerda gerund (-ing) kerak";
    }

    // UK / US spelling check (recognise / recognize)
    const isUKUSMatch =
      userAns.replace(/ise\b/g, 'ize') === targetAns.replace(/ise\b/g, 'ize');
    const isCorrect = userAns === targetAns || isUKUSMatch;

    setFillFeedback({
      submitted: true,
      isCorrect,
      warningMsg
    });
  };

  // -------------------------------------------------------------
  // MODE 2 HANDLERS (Gapni yozing)
  // -------------------------------------------------------------
  const handleSentenceSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!currentItem || sentenceSubmitted) return;
    setSentenceSubmitted(true);
  };

  // -------------------------------------------------------------
  // MODE 3 HANDLERS (Ko'chirib yozing)
  // -------------------------------------------------------------
  const handleCopyChange = (val: string) => {
    setCopyInput(val);
    const targetFull = parsedSentence.fullText;

    // Check if any character typed so far has mismatched
    for (let i = 0; i < val.length; i++) {
      if (val[i] !== targetFull[i]) {
        setCopyHadError(true);
        break;
      }
    }

    // If fully matched
    if (val === targetFull) {
      setCopySubmitted(true);
      setTimeout(() => {
        advanceToNext(!copyHadError);
      }, 700);
    }
  };

  // =============================================================
  // SESSION SUMMARY VIEW
  // =============================================================
  if (isSessionFinished) {
    const percentage = Math.round((score / queue.length) * 100) || 0;
    const hasErrors = failedItems.length > 0;

    return (
      <div className="max-w-xl mx-auto px-4 py-6">
        <div className="retro-card p-6 sm:p-8 bg-paper2 text-center mb-6">
          <Sparkles className="w-12 h-12 text-gold mx-auto mb-2" />
          <h2 className="text-2xl font-serif font-bold text-ink">
            {hasErrors ? 'Mashg\'ulot yakunlandi' : 'Ajoyib natija! Tabriklaymiz!'}
          </h2>
          <p className="text-sm font-mono text-ink/70 mt-1 mb-4">
            Natija: <span className="font-bold text-teal">{score} / {queue.length}</span> ({percentage}%)
          </p>

          <div className="w-full bg-white h-3 rounded-full border border-ink overflow-hidden mb-6">
            <div
              className={`h-full transition-all duration-500 ${
                percentage >= 80 ? 'bg-success' : percentage >= 50 ? 'bg-gold' : 'bg-danger'
              }`}
              style={{ width: `${percentage}%` }}
            />
          </div>

          <div className="flex flex-col sm:flex-row gap-2 justify-center">
            {hasErrors && (
              <button
                onClick={() => startSession(failedItems)}
                className="py-3 px-5 bg-clay hover:bg-danger text-paper font-serif font-bold text-sm rounded border-1.5 border-ink shadow-retro cursor-pointer"
              >
                Xatolarni qayta ishlash ({failedItems.length} ta)
              </button>
            )}

            <button
              onClick={() => startSession(modulePool)}
              className="py-3 px-5 bg-teal hover:bg-teal-dark text-paper font-serif font-bold text-sm rounded border-1.5 border-ink shadow-retro cursor-pointer"
            >
              Yangidan boshlash
            </button>
          </div>
        </div>

        {/* Failed items list */}
        {hasErrors && (
          <div>
            <h3 className="font-serif font-bold text-base text-ink mb-3">
              Xato qilingan gaplar ro'yxati:
            </h3>
            <div className="space-y-3">
              {failedItems.map((item, idx) => {
                const targetMatch = item.s.match(/\[\[(.*?)\]\]/);
                const targetWord = targetMatch ? targetMatch[1] : item.b;
                const cleanSentence = item.s.replace(/\[\[(.*?)\]\]/, '$1');

                return (
                  <div key={idx} className="retro-card p-4 bg-white">
                    <div className="flex items-start justify-between gap-2">
                      <span className="font-mono text-xs font-bold text-clay">
                        #{idx + 1} ({targetWord})
                      </span>
                      <button
                        onClick={() => speakText(cleanSentence)}
                        className="text-teal hover:text-teal-dark p-1"
                        title="Tinglash"
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="font-serif font-bold text-sm sm:text-base text-ink mt-1">
                      {cleanSentence}
                    </p>
                    <p className="font-serif text-xs sm:text-sm text-ink/75 mt-1 italic">
                      {item.u}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    );
  }

  if (!currentItem) return null;

  return (
    <div className="max-w-2xl mx-auto px-3 sm:px-6 py-4 pb-16">
      {/* Top Navigation */}
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={onBackToDashboard}
          className="retro-btn bg-white hover:bg-paper2 px-3 py-1.5 text-xs font-mono font-bold flex items-center gap-1.5 cursor-pointer text-ink"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Bosh sahifa</span>
        </button>

        <button
          onClick={() => setShowTranslation(!showTranslation)}
          className="retro-btn bg-white hover:bg-paper2 px-3 py-1.5 text-xs font-mono font-semibold flex items-center gap-1.5 cursor-pointer text-ink"
          title="Tarjimani ko'rsatish/yashirish"
        >
          {showTranslation ? <EyeOff className="w-3.5 h-3.5 text-clay" /> : <Eye className="w-3.5 h-3.5 text-teal" />}
          <span>{showTranslation ? "Tarjimani yashirish" : "Tarjimani ko'rsatish"}</span>
        </button>
      </div>

      {/* Module Selector (2 Large Buttons: Gerund vs To Infinitive) */}
      <div className="grid grid-cols-2 gap-2 mb-4">
        <button
          onClick={() => setActiveModule('G')}
          className={`py-3 px-3 rounded-md border-1.5 border-ink font-serif font-bold text-sm sm:text-base cursor-pointer transition-all ${
            activeModule === 'G'
              ? 'bg-teal text-paper shadow-retro'
              : 'bg-paper2 text-ink/75 hover:bg-white'
          }`}
        >
          Gerund (-ing) · 46 gap
        </button>

        <button
          onClick={() => setActiveModule('I')}
          className={`py-3 px-3 rounded-md border-1.5 border-ink font-serif font-bold text-sm sm:text-base cursor-pointer transition-all ${
            activeModule === 'I'
              ? 'bg-teal text-paper shadow-retro'
              : 'bg-paper2 text-ink/75 hover:bg-white'
          }`}
        >
          To infinitive · 55 gap
        </button>
      </div>

      {/* Mode Sub-Tabs */}
      <div className="flex border-b-2 border-ink mb-5 overflow-x-auto gap-1">
        {[
          { id: 'fill', label: "1. Bo'shliqni to'ldiring" },
          { id: 'sentence', label: '2. Gapni yozing' },
          { id: 'copy', label: "3. Ko'chirib yozing" }
        ].map(m => (
          <button
            key={m.id}
            onClick={() => setStudyMode(m.id as StudyMode)}
            className={`px-3 py-2 text-xs sm:text-sm font-serif font-bold border-t-2 border-l-2 border-r-2 border-ink rounded-t-md transition-all cursor-pointer whitespace-nowrap ${
              studyMode === m.id
                ? 'bg-paper text-ink -mb-[2px] pb-[10px] border-b-2 border-b-paper font-black text-teal-dark shadow-retro-sm'
                : 'bg-paper2 text-ink/70 hover:bg-white'
            }`}
          >
            {m.label}
          </button>
        ))}
      </div>

      {/* Exercise Progress Header */}
      <div className="flex items-center justify-between mb-2 text-xs font-mono">
        <span className="font-bold text-ink">
          {currentIndex + 1} / {queue.length}
        </span>
        <span className="font-bold text-teal">
          To'g'ri: {score}
        </span>
      </div>

      {/* Visual Progress Bar */}
      <div className="w-full bg-paper2 h-2 rounded-full border border-ink/40 overflow-hidden mb-5">
        <div
          className="bg-teal h-full transition-all duration-300"
          style={{ width: `${((currentIndex + 1) / queue.length) * 100}%` }}
        />
      </div>

      {/* =========================================================== */}
      {/* MODE 1: BO'SHLIQNI TO'LDIRING */}
      {/* =========================================================== */}
      {studyMode === 'fill' && (
        <div className="retro-card p-6 bg-white space-y-5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono font-bold text-teal-dark uppercase px-2 py-0.5 rounded bg-paper2 border border-ink/30">
              Fe'l shaklini kiriting: ({currentItem.b})
            </span>
            <button
              onClick={() => speakText(parsedSentence.fullText)}
              className="text-teal hover:text-teal-dark p-1"
              title="Tinglash"
            >
              <Volume2 className="w-4 h-4" />
            </button>
          </div>

          {/* Sentence display */}
          <div className="text-xl sm:text-2xl font-serif text-ink leading-relaxed">
            <span>{parsedSentence.pre}</span>
            <span
              className={`inline-block px-3 py-0.5 mx-1.5 border-b-2 font-bold font-serif ${
                fillFeedback?.submitted
                  ? fillFeedback.isCorrect
                    ? 'border-success text-success bg-success/10'
                    : 'border-danger text-danger bg-danger/10'
                  : 'border-ink bg-paper2 min-w-[100px] text-center'
              }`}
            >
              {fillFeedback?.submitted ? parsedSentence.target : fillInput || '____'}
            </span>
            <span>{parsedSentence.post}</span>
          </div>

          {/* Uzbek translation */}
          {showTranslation && (
            <p className="text-sm font-serif italic text-ink/75 pt-2 border-t border-line/60">
              {currentItem.u}
            </p>
          )}

          {/* Warning Message if any */}
          {fillFeedback?.warningMsg && (
            <div className="p-2.5 rounded bg-gold/20 border border-gold text-xs font-mono font-bold text-ink">
              ⚠️ {fillFeedback.warningMsg}
            </div>
          )}

          {/* Input Form */}
          {!fillFeedback?.submitted ? (
            <form onSubmit={handleFillSubmit} className="space-y-3 pt-2">
              <input
                ref={activeInputRef as React.RefObject<HTMLInputElement>}
                type="text"
                value={fillInput}
                onChange={e => setFillInput(e.target.value)}
                placeholder={
                  activeModule === 'G'
                    ? "Masalan: stealing"
                    : `Masalan: to ${currentItem.b}`
                }
                className="w-full p-3 bg-paper2 border-1.5 border-ink rounded font-serif text-base text-ink outline-none focus:border-teal"
              />

              <div className="flex gap-2">
                <button
                  type="submit"
                  disabled={!fillInput.trim()}
                  className="flex-1 py-3 bg-teal hover:bg-teal-dark active:translate-x-0.5 active:translate-y-0.5 text-paper font-serif font-bold text-sm rounded border-1.5 border-ink shadow-retro cursor-pointer disabled:opacity-50"
                >
                  Tekshirish (Enter)
                </button>
                <button
                  type="button"
                  onClick={() => advanceToNext(false)}
                  className="px-4 py-3 bg-white hover:bg-paper2 text-clay font-serif font-bold text-sm rounded border-1.5 border-ink shadow-retro cursor-pointer"
                >
                  O'tkazib yuborish
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-3 pt-2">
              <div
                className={`p-3 rounded border-1.5 font-serif text-sm font-bold flex items-center justify-between ${
                  fillFeedback.isCorrect
                    ? 'bg-success/15 text-success border-success'
                    : 'bg-danger/15 text-danger border-danger'
                }`}
              >
                <span>
                  {fillFeedback.isCorrect
                    ? "To'g'ri! Barakalla!"
                    : `Noto'g'ri. To'g'ri javob: ${parsedSentence.target}`}
                </span>
                {fillFeedback.isCorrect ? (
                  <CheckCircle2 className="w-5 h-5 text-success" />
                ) : (
                  <XCircle className="w-5 h-5 text-danger" />
                )}
              </div>

              <button
                onClick={() => advanceToNext(fillFeedback.isCorrect)}
                className="w-full py-3 bg-teal hover:bg-teal-dark active:translate-x-0.5 active:translate-y-0.5 text-paper font-serif font-bold text-sm rounded border-1.5 border-ink shadow-retro cursor-pointer"
              >
                Keyingisi → (Enter)
              </button>
            </div>
          )}
        </div>
      )}

      {/* =========================================================== */}
      {/* MODE 2: GAPNI YOZING (WRITE FULL SENTENCE) */}
      {/* =========================================================== */}
      {studyMode === 'sentence' && (
        <div className="retro-card p-6 bg-white space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono font-bold text-ink/60 uppercase">
              O'zbekcha gapni ingliz tiliga to'liq o'giring:
            </span>
            <button
              type="button"
              onClick={() => setShowLetterHint(!showLetterHint)}
              className="retro-btn bg-paper2 hover:bg-white text-ink text-[11px] font-mono font-bold px-2 py-1 flex items-center gap-1 cursor-pointer"
            >
              <Lightbulb className="w-3.5 h-3.5 text-gold" />
              <span>Maslahat (H_)</span>
            </button>
          </div>

          {/* Large Uzbek translation prompt */}
          <div className="p-4 bg-paper2 border border-ink/40 rounded-md">
            <h2 className="text-lg sm:text-xl font-serif font-bold text-ink leading-snug">
              {currentItem.u}
            </h2>
          </div>

          {/* Letter hint */}
          {showLetterHint && (
            <div className="p-3 bg-gold/15 border border-gold/40 rounded font-mono text-xs text-ink/90">
              <span className="font-bold text-[10px] text-teal-dark uppercase block mb-0.5">
                Harf shablon:
              </span>
              {generateLetterHint(parsedSentence.fullText)}
            </div>
          )}

          {/* User Input & Result */}
          {!sentenceSubmitted ? (
            <form onSubmit={handleSentenceSubmit} className="space-y-3">
              <textarea
                ref={activeInputRef as React.RefObject<HTMLTextAreaElement>}
                rows={3}
                value={sentenceInput}
                onChange={e => setSentenceInput(e.target.value)}
                placeholder="To'liq inglizcha gapni yozing..."
                className="w-full p-3 bg-paper2 border-1.5 border-ink rounded font-serif text-base text-ink outline-none focus:border-teal resize-none"
              />

              <div className="flex gap-2">
                <button
                  type="submit"
                  disabled={!sentenceInput.trim()}
                  className="flex-1 py-3 bg-teal hover:bg-teal-dark active:translate-x-0.5 active:translate-y-0.5 text-paper font-serif font-bold text-sm rounded border-1.5 border-ink shadow-retro cursor-pointer disabled:opacity-50"
                >
                  Tekshirish (Enter)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSentenceSubmitted(true);
                  }}
                  className="px-4 py-3 bg-white hover:bg-paper2 text-clay font-serif font-bold text-sm rounded border-1.5 border-ink shadow-retro cursor-pointer"
                >
                  O'tkazib yuborish
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-4">
              {/* Diff Analysis */}
              {(() => {
                const { userWordsDiff, isFullyCorrect } = compareSentenceWords(
                  sentenceInput,
                  parsedSentence.fullText
                );

                return (
                  <div className="space-y-3">
                    <div className="p-3 rounded border border-ink/40 bg-paper2">
                      <span className="text-[11px] font-mono text-ink/60 font-bold block mb-1">
                        Sizning yozganingiz:
                      </span>
                      <div className="text-base font-serif flex flex-wrap gap-1.5">
                        {userWordsDiff.length === 0 ? (
                          <span className="text-danger italic">[hech narsa yozilmadi]</span>
                        ) : (
                          userWordsDiff.map((w, idx) => (
                            <span
                              key={idx}
                              className={`px-1 rounded ${
                                w.isCorrect
                                  ? 'text-success font-bold'
                                  : 'text-danger line-through bg-danger/10'
                              }`}
                            >
                              {w.word}
                            </span>
                          ))
                        )}
                      </div>
                    </div>

                    <div className="p-3 rounded border border-success/40 bg-success/10">
                      <span className="text-[11px] font-mono text-success font-bold block mb-1">
                        To'g'ri gap:
                      </span>
                      <p className="text-base font-serif font-bold text-ink">
                        {parsedSentence.fullText}
                      </p>
                    </div>

                    <button
                      onClick={() => advanceToNext(isFullyCorrect)}
                      className="w-full py-3 bg-teal hover:bg-teal-dark active:translate-x-0.5 active:translate-y-0.5 text-paper font-serif font-bold text-sm rounded border-1.5 border-ink shadow-retro cursor-pointer"
                    >
                      Keyingisi → (Enter)
                    </button>
                  </div>
                );
              })()}
            </div>
          )}
        </div>
      )}

      {/* =========================================================== */}
      {/* MODE 3: KO'CHIRIB YOZING (COPY TYPE WITH REALTIME MATCH) */}
      {/* =========================================================== */}
      {studyMode === 'copy' && (
        <div className="retro-card p-6 bg-white space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono font-bold text-ink/60 uppercase">
              Quyidagi gapni aynan ko'chirib yozing:
            </span>
            <button
              onClick={() => speakText(parsedSentence.fullText)}
              className="text-teal hover:text-teal-dark p-1"
              title="Tinglash"
            >
              <Volume2 className="w-4 h-4" />
            </button>
          </div>

          {/* Reference sentence with highlighted target structure */}
          <div className="p-4 bg-paper2 border-1.5 border-ink rounded text-lg sm:text-xl font-serif leading-relaxed">
            <span>{parsedSentence.pre}</span>
            <mark className="bg-gold px-1 rounded font-bold text-ink mx-0.5">
              {parsedSentence.target}
            </mark>
            <span>{parsedSentence.post}</span>
          </div>

          {/* Real-time typing visualizer */}
          <div className="p-3 border border-ink/40 rounded bg-white font-mono text-sm sm:text-base leading-relaxed tracking-wider break-words min-h-[50px]">
            {parsedSentence.fullText.split('').map((char, idx) => {
              const userChar = copyInput[idx];
              let style = 'text-ink/40';

              if (userChar !== undefined) {
                if (userChar === char) {
                  style = 'text-success font-bold bg-success/20 rounded-xs';
                } else {
                  style = 'text-white font-bold bg-danger rounded-xs';
                }
              } else if (idx === copyInput.length) {
                // Active cursor
                style = 'border-b-2 border-teal text-ink font-bold animate-pulse';
              }

              return (
                <span key={idx} className={style}>
                  {char}
                </span>
              );
            })}
          </div>

          {/* Uzbek translation */}
          {showTranslation && (
            <p className="text-xs sm:text-sm font-serif italic text-ink/75">
              {currentItem.u}
            </p>
          )}

          {/* Active typing input */}
          <input
            ref={activeInputRef as React.RefObject<HTMLInputElement>}
            type="text"
            value={copyInput}
            onChange={e => handleCopyChange(e.target.value)}
            placeholder="Gapni aynan yuqoridagidek yozing..."
            className="w-full p-3 bg-paper2 border-1.5 border-ink rounded font-serif text-base text-ink outline-none focus:border-teal"
          />

          <div className="flex items-center justify-between text-xs font-mono text-ink/70">
            <span>
              {copyHadError ? (
                <span className="text-danger font-bold">Xato yozildi (qayta ishlashga tushadi)</span>
              ) : (
                <span className="text-success font-bold">Xatosiz yozilmoqda</span>
              )}
            </span>
            <button
              onClick={() => advanceToNext(false)}
              className="text-clay hover:underline cursor-pointer"
            >
              O'tkazib yuborish
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
